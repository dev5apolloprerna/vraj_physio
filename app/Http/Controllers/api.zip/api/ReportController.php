<?php
namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Session;

use App\Models\SessionMaster;
use App\Models\Treatment;
use App\Models\Patient;
use App\Models\User;
use App\Models\Order;
use App\Models\OrderPayment;
use App\Models\PatientSchedule;
use App\Models\PatientSuggestedTreatment;
use App\Models\Plan;

use Maatwebsite\Excel\Facades\Excel;
use App\Exports\SessionExport;
use App\Exports\TreatmentExport;
use App\Exports\PatientPayment;
use App\Exports\TotalCollection;
use App\Exports\PatientCollection;
use App\Exports\TotalAttended;
use App\Exports\DailyCollection;
use App\Exports\GroupSessionExport;
use App\Exports\PatientVisit;

use App\Models\PatientTreatmentLedger;
class ReportController extends Controller
{

public function patient_attended_session(Request $request)
{
    try {
        if (!auth()->guard('api')->user()) {
            return response()->json([
                'status' => 'error',
                'message' => 'User is not Authorised.',
            ], 401);
        }

        $user = auth()->guard('api')->user();

        if ($request->device_token != $user->device_token) {
            return response()->json([
                "ErrorCode" => "1",
                'Status' => 'Failed',
                'Message' => 'Device Token Not Match',
            ], 401);
        }

        $attendedSession = SessionMaster::from('sessionmaster as sm')
            ->select([
                'sm.created_at',
                'sm.iSessionTakenId',
                'pst.iOrderDetailId',
                'pst.iUsedSession',
                DB::raw("'regular' as entry_type"),
                'tm.treatment_name',
                'u.name as therapist_name',
                'op.invoice_no',
                DB::raw('CONCAT(pm.patient_first_name, " ", pm.patient_last_name) as patient_name'),
                'plan_master.per_session_amount',
                'pi.isGroupSession',
            ])
            ->join('patient_schedule as ps', function ($join) {
                $join->on('ps.patient_schedule_id', '=', 'sm.scheduleid')
                    ->on('ps.patient_id', '=', 'sm.patient_id')
                    ->on('ps.treatment_id', '=', 'sm.treatment_id');
            })
            ->join('patient_suggested_treatment as pst', function ($join) {
                $join->on('pst.iOrderId', '=', 'ps.orderId')
                    ->on('pst.patient_id', '=', 'sm.patient_id')
                    ->on('pst.treatment_id', '=', 'sm.treatment_id');
            })
            ->join('patientorderdetail as pod', 'pod.iOrderDetailId', '=', 'pst.iOrderDetailId')
            ->leftJoin('plan_master', 'plan_master.plan_id', '=', 'pod.iPlanId')
            ->leftJoin('treatment_master as tm', 'tm.treatment_id', '=', 'sm.treatment_id')
            ->leftJoin('users as u', 'u.id', '=', 'sm.therapist_id')
            ->leftJoin('patient_master as pm', 'pm.patient_id', '=', 'sm.patient_id')
            ->leftJoin('orderpayment as op', 'op.orderDetailId', '=', 'pst.iOrderDetailId')
            ->leftJoin('patientin as pi', 'pi.iPatientInId', '=', 'sm.iPatientInId')
            ->where('sm.session_status', 2)
            ->when($request->fromdate, function ($query) use ($request) {
                return $query->where('sm.created_at', '>=', date('Y-m-d 00:00:00', strtotime($request->fromdate)));
            })
            ->when($request->todate, function ($query) use ($request) {
                return $query->where('sm.created_at', '<=', date('Y-m-d 23:59:59', strtotime($request->todate)));
            })
            ->when($request->month, function ($query) use ($request) {
                return $query->whereMonth('sm.created_at', $request->month);
            })
            ->when($request->year, function ($query) use ($request) {
                return $query->whereYear('sm.created_at', $request->year);
            })
            ->orderBy('sm.created_at', 'asc')
            ->orderBy('sm.iSessionTakenId', 'asc')
            ->get();

        $manualSessions = DB::table('patienttreatementledger as ptl')
            ->select([
                'ptl.created_at',
                'ptl.iSessionTakenId',
                'ptl.iLedgerId',
                'ptl.iOrderDetailId',
                'ptl.manually_consumed',
                DB::raw("'manual' as entry_type"),
                'tm.treatment_name',
                'u.name as therapist_name',
                'op.invoice_no',
                DB::raw('CONCAT(pm.patient_first_name, " ", pm.patient_last_name) as patient_name'),
                'plan_master.per_session_amount',
                DB::raw('0 as isGroupSession'),
            ])
            ->leftJoin('patientorderdetail as pod', 'pod.iOrderDetailId', '=', 'ptl.iOrderDetailId')
            ->leftJoin('plan_master', 'plan_master.plan_id', '=', 'pod.iPlanId')
            ->leftJoin('treatment_master as tm', 'tm.treatment_id', '=', 'ptl.treatment_id')
            ->leftJoin('users as u', 'u.id', '=', 'ptl.therapist_id')
            ->leftJoin('patient_master as pm', 'pm.patient_id', '=', 'ptl.patient_id')
            ->leftJoin('orderpayment as op', 'op.orderDetailId', '=', 'ptl.iOrderDetailId')
            ->whereNotNull('ptl.manually_consumed')
            ->where('ptl.manually_consumed', '>', 0)
            ->when($request->fromdate, function ($query) use ($request) {
                return $query->where('ptl.created_at', '>=', date('Y-m-d 00:00:00', strtotime($request->fromdate)));
            })
            ->when($request->todate, function ($query) use ($request) {
                return $query->where('ptl.created_at', '<=', date('Y-m-d 23:59:59', strtotime($request->todate)));
            })
            ->when($request->month, function ($query) use ($request) {
                return $query->whereMonth('ptl.created_at', $request->month);
            })
            ->when($request->year, function ($query) use ($request) {
                return $query->whereYear('ptl.created_at', $request->year);
            })
            ->orderBy('ptl.created_at', 'asc')
            ->orderBy('ptl.iLedgerId', 'asc')
            ->get();

        $sessionList = [];
        $sessionList2 = [];

        $allRows = $attendedSession->concat($manualSessions)->sortBy(function ($row) {
            return sprintf(
                '%s-%010d-%010d',
                $row->created_at,
                (int) ($row->iSessionTakenId ?? 0),
                (int) ($row->iLedgerId ?? 0)
            );
        })->values();

        foreach ($allRows as $row) {
            if (($row->entry_type ?? '') === 'manual') {
                $consumedSession = (float) ($row->manually_consumed ?? 0);
            } else {
                $consumedSession = (float) ($row->iUsedSession ?? 0);
            }

            $amount = (float) ($row->per_session_amount ?? 0);
            $total = $amount * $consumedSession;
            $groupSession = ((int) ($row->isGroupSession ?? 0) === 1) ? 'yes' : 'no';

            $sessionList[] = [
                "invoice_no" => $row->invoice_no ?? '-',
                "date" => $row->created_at,
                "patient_name" => $row->patient_name ?? '-',
                "therapist_name" => $row->therapist_name ?? '-',
                "treatment_name" => $row->treatment_name ?? '-',
                // "consumed_session" => $consumedSession,
                "total_session_amount" => $amount,
                "group_session" => $groupSession,
                "session_taken_id" => $row->iSessionTakenId ?? null,
                "ledger_id" => $row->iLedgerId ?? null,
                "total_amount" => $total,
            ];

            $sessionList2[] = [
                "invoice_no" => $row->invoice_no ?? '-',
                "date" => $row->created_at,
                "patient_name" => $row->patient_name ?? '-',
                "therapist_name" => $row->therapist_name ?? '-',
                "treatment_name" => $row->treatment_name ?? '-',
                "group_session" => $groupSession,
                "total_session_amount" => $amount,
            ];
        }

        if ($request->status == 1) {
            $export = new SessionExport(
                $sessionList2,
                $request->fromdate,
                $request->todate,
                $request->month,
                $request->year
            );

            $basePath = '/home3/vrajdahj/vrajphysioapp.vrajdentalclinic.com/reports';
            if (!file_exists($basePath)) {
                mkdir($basePath, 0755, true);
            }

            $fileName = 'Patient_attended_session_report_' . now()->format('Y_m_d_H_i_s') . '.xlsx';
            Excel::store($export, 'export/' . $fileName, 'public');

            return response()->json([
                'status' => 'success',
                'file_url' => asset('reports/export/' . $fileName)
            ]);
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Attended Session List',
            'Attended Session List' => $sessionList,
        ]);
    } catch (ValidationException $e) {
        return response()->json(['errors' => $e->errors()], 422);
    } catch (\Throwable $th) {
        return response()->json(['error' => $th->getMessage()], 500);
    }
}
    public function total_session_report(Request $request)
    {
        try 
        {
            if(auth()->guard('api')->user())
            {
                 $User = auth()->guard('api')->user();
                 
                    if($request->device_token != $User->device_token)
                    {
                        return response()->json([
                            "ErrorCode" => "1",
                            'Status' => 'Failed',
                            'Message' => 'Device Token Not Match',
                        ], 401);
                    }

                    
                    $treatment = SessionMaster::selectRaw('sessionmaster.treatment_id,COUNT(*) as session_count,pst.iUsedSession,
                        (SELECT treatment_name FROM treatment_master WHERE treatment_master.treatment_id = sessionmaster.treatment_id LIMIT 1) AS treatment_name,
                        (SELECT per_session_amount FROM plan_master WHERE plan_master.plan_id = pod.iPlanId LIMIT 1) AS per_session_amount,
                        (SELECT clinic_id FROM plan_master WHERE plan_master.treatment_id = sessionmaster.treatment_id LIMIT 1) AS clinic_id'
                        )
                        ->where(['session_status' => 2])
                        ->when($request->fromdate, fn($query, $FromDate) =>$query->where('sessionmaster.created_at', '>=', date('Y-m-d 00:00:00', strtotime($FromDate))))
                        ->when($request->todate, fn($query, $ToDate) =>$query->where('sessionmaster.created_at', '<=', date('Y-m-d 23:59:59', strtotime($ToDate))))
                        ->when($request->month, fn($query, $month) => $query->whereMonth('sessionmaster.created_at', $month))
                        ->when($request->year, fn($query, $year) =>$query->whereYear('sessionmaster.created_at', $year))
                        ->join('patient_schedule AS ps', 'ps.patient_schedule_id', '=', 'sessionmaster.scheduleid')
                        ->join('patient_suggested_treatment AS pst', 'pst.iOrderId', '=', 'ps.orderId')
                        ->join('patientorderdetail AS pod', 'pod.iOrderId', '=', 'ps.orderId')
                        ->groupBy('sessionmaster.treatment_id') 
                        ->get();
                        

                    if (!$treatment->isEmpty()) 
                    {
                        $grandtotal = 0;  // Move grand total outside the loop
                        $treatmentList = [];
                        $session=0;
                        $amount=0;
                        $grandtotal=0;
                        $totalsession=0;
                        $totalamount=0;
                        $total=0;
                        foreach ($treatment as $val) 
                        {
                            /*$session = $val->iUsedSession;*/
                            $session = $val->session_count;
                            $amount = $val->per_session_amount;
                            $total = $amount * $session;
                            
                            $grandtotal += $total; // Accumulate grand total correctly
                            $totalsession += $session; // Accumulate grand total correctly
                            $totalamount += $amount; // Accumulate grand total correctly
                    
                            $treatmentList[] = [
                                "clinic_id" => $val->clinic_id,
                                "treatment_id" => $val->treatment_id,
                                "treatment_name" => $val->treatment_name,
                                /*"attended_session" => $val->iUsedSession,*/
                                "attended_session" => $val->session_count,
                                "amount" => $amount,
                                "total" => $total
                            ];
                                $treatmentList2[] = array
                                (
                                "treatment_name" => $val->treatment_name,
                                "attended_session" => $val->session_count ?? '-',
                                "amount" => $amount,
                                "total" => $total
                                );
                        }

                    if($request->status == 1)
                    {
                    
                      $export = new TreatmentExport($treatmentList2, $request->fromdate, $request->todate, $request->month, $request->year);

                    // Define the target directory and ensure it exists
                    $basePath = '/home3/vrajdahj/vrajphysioapp.vrajdentalclinic.com/reports';
                    if (!file_exists($basePath)) {
                        mkdir($basePath, 0755, true); // Create the directory with appropriate permissions
                    }
                    
                    // Define the file path
                    $fileName = 'Collection_of_Treatment_' . now()->format('Y_m_d_H_i_s') . '.xlsx';
                    $filePath = $basePath . '/' . $fileName;
                    
                    // Store the Excel file
                    Excel::store($export, 'export/' . $fileName, 'public'); // Adjust path relative to 'public' disk
                    
                    // Generate the public file URL
                    $fileUrl = asset('reports/export/' . $fileName);
                    
                    return response()->json([
                        'status' => 'success',
                        'file_url' => $fileUrl]);
                        
                    }
                    
                            return response()->json([
                                'status' => 'success',
                                'message' => 'Total Session Report',
                                "total_session"=>$totalsession,
                                "total_amount"=>$totalamount,
                                "total"=>$grandtotal,
                                'total_session_report' => $treatmentList
                            ]);
                        }else{
                            return response()->json([
                                'status' => 'error',
                                'message' => 'Total Session Report',
                                'total_session_report' => []
                            ],401);
                        }



            }else{
                return response()->json([
                        'status' => 'error',
                        'message' => 'User is not Authorised.',
                ], 401);
            }
        } catch (ValidationException $e) {
            return response()->json(['errors' => $e->errors()], 422);
        } catch (\Throwable $th) {
            return response()->json(['error' => $th->getMessage()], 500);
        }
    }
    public function patient_payment_collection(Request $request)
    {
        try 
        {
            if(auth()->guard('api')->user())
            {
                 $User = auth()->guard('api')->user();
                 
                    if($request->device_token != $User->device_token)
                    {
                        return response()->json([
                            "ErrorCode" => "1",
                            'Status' => 'Failed',
                            'Message' => 'Device Token Not Match',
                        ], 401);
                    }

                    $doctortreatment = OrderPayment::select(
                    'orderpayment.*',
                    'pom.patient_id',
                    'pm.clinic_id',
                    'ps.therapist_id',
                    'pod.iTreatmentId',
                    
                    DB::raw("(SELECT CONCAT(pm.patient_first_name, ' ', pm.patient_last_name) 
                              FROM patient_master pm WHERE pm.patient_id = pom.patient_id LIMIT 1) AS patient_name"),
                    DB::raw("(SELECT u.name FROM users u WHERE ps.therapist_id = u.id LIMIT 1) AS therapist_name"),
                    DB::raw("(SELECT tm.treatment_name FROM treatment_master tm WHERE tm.treatment_id = pod.iTreatmentId LIMIT 1) AS treatment_name")
                )
                ->join('patientorderdetail AS pod', 'pod.iOrderDetailId', '=', 'orderpayment.orderDetailId')
                ->join('patientordermaster AS pom', 'pom.iOrderId', '=', 'pod.iOrderId')
                ->join('patient_master AS pm', 'pm.patient_id', '=', 'pom.patient_id')
                ->leftJoin('patient_schedule AS ps', 'ps.treatment_id', '=', 'pod.iTreatmentId')
                ->where('pm.clinic_id', $request->clinic_id)
                ->when($request->fromdate, fn ($query, $FromDate) => $query->where('PaymentDateTime', '>=', date('Y-m-d 00:00:00', strtotime($FromDate))))
                ->when($request->todate, fn ($query, $ToDate) => $query->where('PaymentDateTime', '<=', date('Y-m-d 23:59:59', strtotime($ToDate))))
                ->when($request->month, fn ($query, $month) => $query->whereMonth('PaymentDateTime', $month))
                ->when($request->year, fn ($query, $year) => $query->whereYear('PaymentDateTime', $year))
                ->when($request->therapist_id, fn ($query, $TherapistId) => $query->where('ps.therapist_id', '=', $TherapistId))
                ->groupBy('orderpayment.orderDetailId') // Ensures unique records
                ->get();


                    if(sizeof($doctortreatment) != 0)
                      {
                            foreach ($doctortreatment as $key => $val) 
                            {
                                $drtreatmentList[] = array
                                (
                                    "clinic_id" => $val->clinic_id,
                                    "therapist_id" => $val->therapist_id,
                                    "therapist_name" => $val->therapist_name,
                                    "treatment_id" => $val->iTreatmentId,
                                    "treatment_name" => $val->treatment_name,
                                    "patient_id"=>$val->patient_id,
                                    "patient_name"=>$val->patient_name,
                                    "amount"=>$val->Amount,
                                    "payment_mode"=>$val->payment_mode,
                                );
                                
                                $drtreatmentList2[] = array
                                (
                                    "clinic_id" => $val->clinic_id,
                                    "patient_name"=>$val->patient_name,
                                    "therapist_name" => $val->therapist_name,
                                    "treatment_name" => $val->treatment_name,
                                    "amount"=>$val->Amount,
                                    "payment_mode"=>$val->payment_mode,
                                );
                            }

    
                            if($request->status == 1)
                        {
                        
                          $export = new PatientPayment($drtreatmentList2, $request->fromdate, $request->todate, $request->month, $request->year);
    
                        // Define the target directory and ensure it exists
                        $basePath = '/home3/vrajdahj/vrajphysioapp.vrajdentalclinic.com/reports';
                        if (!file_exists($basePath)) {
                            mkdir($basePath, 0755, true); // Create the directory with appropriate permissions
                        }
                        
                        // Define the file path
                        $fileName = 'Patient_Payment_Collection_report_' . now()->format('Y_m_d_H_i_s') . '.xlsx';
                        $filePath = $basePath . '/' . $fileName;
                        
                        // Store the Excel file
                        Excel::store($export, 'export/' . $fileName, 'public'); // Adjust path relative to 'public' disk
                        
                        // Generate the public file URL
                        $fileUrl = asset('reports/export/' . $fileName);
                        
                        return response()->json([
                            'status' => 'success',
                            'file_url' => $fileUrl]);
                            
                        }
                        
                            return response()->json([
                                'status' => 'success',
                                'message' => 'Patient Payment Collection',
                                'payment_collection' => $drtreatmentList
                            ]);
                        }else{
                            return response()->json([
                                'status' => 'error',
                                'message' => 'Patient Payment Collection',
                                'payment_collection' => []
                            ],401);
                        }



            }else{
                return response()->json([
                        'status' => 'error',
                        'message' => 'User is not Authorised.',
                ], 401);
            }
        } catch (ValidationException $e) {
            return response()->json(['errors' => $e->errors()], 422);
        } catch (\Throwable $th) {
            return response()->json(['error' => $th->getMessage()], 500);
        }
    }
    public function patient_due_amount_msg(Request $request)
    {
        try 
        {
            if(auth()->guard('api')->user())
            {
                 $User = auth()->guard('api')->user();
                 
                    if($request->device_token != $User->device_token)
                    {
                        return response()->json([
                            "ErrorCode" => "1",
                            'Status' => 'Failed',
                            'Message' => 'Device Token Not Match',
                        ], 401);
                    }

                    $data=Order::select('patient_master.phone','DueAmount','patientordermaster.patient_id')->where(['patientordermaster.patient_id'=>$request->patient_id,'clinic_id'=>$request->clinic_id])->join('patient_master', 'patient_master.patient_id', '=', 'patientordermaster.patient_id')->latest('patientordermaster.created_at')->first(); 

                        $key = $_ENV['WHATSAPPKEY'];
                        $users = new User();
                        $msg = "Dear Parent,\n\n"
                            . "This is a reminder that your payment is due. Kindly make the payment at your earliest convenience to avoid any interruptions in services.\n\n"
                            . "*Payment Details:*\n"
                            . "• *Due Amount:* {$data->DueAmount}\n\n"
                            . "For any queries or assistance, please feel free to contact us.\n\n"
                            . "Thank you!";

                        $status = $users->sendWhatsappMessage($data->phone,$key,$msg, $someOtherParam = null);

                        return response()->json([
                        'status' => 'success',
                        'message' => 'Whats app send Successfully',

                    ], 401);

            }else{
                return response()->json([
                        'status' => 'error',
                        'message' => 'User is not Authorised.',
                ], 401);
            }
         } catch (ValidationException $e) {
            return response()->json(['errors' => $e->errors()], 422);
        } catch (\Throwable $th) {
            return response()->json(['error' => $th->getMessage()], 500);
        }
    }
    public function total_collection_report(Request $request)
    {
        try
        {
            if(auth()->guard('api')->user())
            {
                 $User = auth()->guard('api')->user();
                 
                    if($request->device_token != $User->device_token)
                    {
                        return response()->json([
                            "ErrorCode" => "1",
                            'Status' => 'Failed',
                            'Message' => 'Device Token Not Match',
                        ], 401);
                    }
                $OrderPayment=OrderPayment::select('orderpayment.*')
                    ->when($request->fromdate || $request->todate || $request->month || $request->year, function ($query) use ($request) 
                        {
                            if ($request->fromdate) {
                                $query->where('PaymentDateTime', '>=', date('Y-m-d 00:00:00', strtotime($request->fromdate)));
                            }
                            if ($request->todate) {
                                $query->where('PaymentDateTime', '<=', date('Y-m-d 23:59:59', strtotime($request->todate)));
                            }
                            if ($request->month) {
                                $query->whereMonth('PaymentDateTime', $request->month);
                            }
                            if ($request->year) {
                                $query->whereYear('PaymentDateTime', $request->year);
                            }

                        })  // Ensuring unique payments
                    ->get();

                    if(sizeof($OrderPayment) != 0)
                    {

                        $opayment = 0;
                        $cashpayment = 0;
                        $npayment = 0;
                        $cardpayment = 0;
                        $totalamount = 0;
                        
                        $online = 0;
                        $cash = 0;
                        $NEFT = 0;
                        $card = 0;
                        
                        $pList = [];
                        
                        foreach ($OrderPayment as $key => $val) 
                        {
                            // Reset values for each order
                            $opayment = 0;
                            $cashpayment = 0;
                            $npayment = 0;
                            $cardpayment = 0;
                        
                            if ($val->payment_mode == 'Online') {
                                $opayment = $val->Amount;
                            }
                            if ($val->payment_mode == 'Cash') {
                                $cashpayment = $val->Amount;
                            }
                            if ($val->payment_mode == 'NEFT') {
                                $npayment = $val->Amount;
                            }     
                            if ($val->payment_mode == 'Card') {
                                $cardpayment = $val->Amount;
                            }
                        
                            $totalamount = $opayment + $cardpayment + $npayment + $cashpayment;
                        
                            $pList[] = [
                                //"order_id" => $val->iOrderId,
                                //"order_detail_id" => $val->orderDetailId,
                                "payment_date" => date('d-M-Y', strtotime($val->PaymentDateTime)),
                                "Online" => $opayment ?: '-',
                                "Cash" => $cashpayment ?: '-',
                                "NEFT" => $npayment ?: '-',
                                "Card" => $cardpayment ?: '-',
                                "Total_Amount" => $totalamount ?: '-',
                            ];
                        
                            // Accumulate totals
                            $online += $opayment;
                            $cash += $cashpayment;
                            $NEFT += $npayment;
                            $card += $cardpayment;  // Corrected from $npayment
                        }

                          if($request->status == 1)
                        {
                        
                          $export = new TotalCollection($pList, $request->fromdate, $request->todate, $request->month, $request->year);
    
                        // Define the target directory and ensure it exists
                        $basePath = '/home3/vrajdahj/vrajphysioapp.vrajdentalclinic.com/reports';
                        if (!file_exists($basePath)) {
                            mkdir($basePath, 0755, true); // Create the directory with appropriate permissions
                        }
                        
                        // Define the file path
                        $fileName = 'Total_Collection_report_' . now()->format('Y_m_d_H_i_s') . '.xlsx';
                        $filePath = $basePath . '/' . $fileName;
                        
                        // Store the Excel file
                        Excel::store($export, 'export/' . $fileName, 'public'); // Adjust path relative to 'public' disk
                        
                        // Generate the public file URL
                        $fileUrl = asset('reports/export/' . $fileName);
                        
                        return response()->json([
                            'status' => 'success',
                            'file_url' => $fileUrl]);
                            
                        }
                                return response()->json([
                                    'status' => 'success',
                                    'message' => 'Total Collection Report',
                                    'total_online' => $online,
                                    'total_cash' => $cash,
                                    'total_NEFT' => $NEFT,
                                    'total_card' => $card,

                                    'total_collection' => $pList
                                ]);

                    } else 
                    {
                        return response()->json([
                            'status' => 'error',
                            'message' => 'No Data Found!',
                            'total_collection' => []
                        ]);
                    }



            }else{
                    return response()->json([
                            'status' => 'error',
                            'message' => 'User is not Authorised.',
                    ], 401);
                }

        } catch (ValidationException $e) {
            return response()->json(['errors' => $e->errors()], 422);
        } catch (\Throwable $th) {
            return response()->json(['error' => $th->getMessage()], 500);
        }
    }
    public function total_attended_session_report(Request $request)
    {

     try 
        {
            if(auth()->guard('api')->user())
            {
                 $User = auth()->guard('api')->user();
                 
                    if($request->device_token != $User->device_token)
                    {
                        return response()->json([
                            "ErrorCode" => "1",
                            'Status' => 'Failed',
                            'Message' => 'Device Token Not Match',
                        ], 401);
                    }


                $attendedSession=SessionMaster::select('sessionmaster.patient_id','patient_master.clinic_id','sessionmaster.treatment_id','sessionmaster.created_at',DB::raw("(SELECT CONCAT(patient_master.patient_first_name, ' ', patient_master.patient_last_name)FROM patient_master WHERE patient_master.patient_id = sessionmaster.patient_id LIMIT 1) AS patient_name")
                    ,DB::raw("(select treatment_name from treatment_master where sessionmaster.treatment_id=treatment_master.treatment_id limit 1) as treatment_name")
            )
                        ->where('sessionmaster.session_status', 2)
                        ->where(['patient_master.clinic_id'=>$request->clinic_id])
                        ->join('patient_master', 'patient_master.patient_id', '=', 'sessionmaster.patient_id') // Join to get clinic_id
                        ->when($request->fromdate, fn ($query, $FromDate) => $query->where('sessionmaster.created_at', '>=', date('Y-m-d 00:00:00', strtotime($FromDate))))
                        ->when($request->todate, fn ($query, $ToDate) => $query->where('sessionmaster.created_at', '<=', date('Y-m-d 23:59:59', strtotime($ToDate))))
                        ->when($request->month, fn ($query, $month) => $query->whereMonth('sessionmaster.created_at', $month))
                        ->when($request->year, fn ($query, $year) => $query->whereYear('sessionmaster.created_at', $year))

                         ->get();
                         
                         $sessionList=[];
                         
                    foreach ($attendedSession as $key => $val) 
                    {

                                $sessionList[] = array
                                (
                                    "date" => $val->created_at,
                                    "patient_name" => $val->patient_name,
                                    "treatment_name" => $val->treatment_name ?? '-',
                                    "amount"=>"",
                                    "payment_mode"=>""
                                );
                    }
                    
                     if($request->status == 1)
                    {
                    
                      $export = new TotalAttended($sessionList, $request->fromdate, $request->todate, $request->month, $request->year);

                    // Define the target directory and ensure it exists
                    $basePath = '/home3/vrajdahj/vrajphysioapp.vrajdentalclinic.com/reports';
                    if (!file_exists($basePath)) {
                        mkdir($basePath, 0755, true); // Create the directory with appropriate permissions
                    }
                    
                    // Define the file path
                    $fileName = 'Total_Attended_Session_report' . now()->format('Y_m_d_H_i_s') . '.xlsx';
                    $filePath = $basePath . '/' . $fileName;
                    
                    // Store the Excel file
                    Excel::store($export, 'export/' . $fileName, 'public'); // Adjust path relative to 'public' disk
                    
                    // Generate the public file URL
                    $fileUrl = asset('reports/export/' . $fileName);
                    
                    return response()->json([
                        'status' => 'success',
                        'file_url' => $fileUrl]);
                        
                    }
                    
                    
                    return response()->json([
                        'status' => 'success',
                        'message' => 'Total Attended Session Report',
                        'total_attended_session' => $sessionList,
                    ]);


        }else{
                return response()->json([
                        'status' => 'error',
                        'message' => 'User is not Authorised.',
                ], 401);
            }
        } catch (ValidationException $e) {
            return response()->json(['errors' => $e->errors()], 422);
        } catch (\Throwable $th) {
            return response()->json(['error' => $th->getMessage()], 500);
        }
    }
    public function daily_collection_report(Request $request)
    {
        try
        {
            if(auth()->guard('api')->user())
            {
                 $User = auth()->guard('api')->user();
                 
                    if($request->device_token != $User->device_token)
                    {
                        return response()->json([
                            "ErrorCode" => "1",
                            'Status' => 'Failed',
                            'Message' => 'Device Token Not Match',
                        ], 401);
                    }

                $OrderPayment=OrderPayment::select('orderpayment.*',DB::raw("(SELECT CONCAT(patient_master.patient_first_name, ' ', patient_master.patient_last_name) 
                  FROM patient_master WHERE patient_master.patient_id = patientordermaster.patient_id LIMIT 1) AS patient_name")
                    ,'patientordermaster.patient_id','patientordermaster.DueAmount','patientordermaster.iAmount')
                    ->join('patientorderdetail', 'patientorderdetail.iOrderDetailId', '=', 'orderpayment.orderDetailId')
                    ->join('patientordermaster', 'patientordermaster.iOrderId', '=', 'patientorderdetail.iOrderId')
                    ->when($request->fromdate || $request->todate || $request->month || $request->year, function ($query) use ($request) 
                        {
                            if ($request->fromdate) {
                                $query->where('PaymentDateTime', '>=', date('Y-m-d 00:00:00', strtotime($request->fromdate)));
                            }
                            if ($request->todate) {
                                $query->where('PaymentDateTime', '<=', date('Y-m-d 23:59:59', strtotime($request->todate)));
                            }
                            if ($request->month) {
                                $query->whereMonth('PaymentDateTime', $request->month);
                            }
                            if ($request->year) {
                                $query->whereYear('PaymentDateTime', $request->year);
                            }
                        }, function ($query) {
                            $query->whereDate('PaymentDateTime', today());
                        })
                    ->get();
                    if(sizeof($OrderPayment) != 0)
                    {

                        foreach ($OrderPayment as $key => $val) 
                        {
                             $totalPaid = OrderPayment::where(['iOrderId' => $val->iOrderId])->sum('Amount');
                             
                                $pList[] = array(
                                    "payment_date" => date('d-M-Y',strtotime($val->PaymentDateTime)),
                                    "receipt_no"=>$val->OrderPaymentId ?? 0,
                                    "patient_name" => $val->patient_name,
                                    "amount"=>$totalPaid ?? 0,
                                    "payment_mode" => $val->payment_mode,
                                );
                        }
                        
                         if($request->status == 1)
                    {
                    
                      $export = new DailyCollection($pList, $request->fromdate, $request->todate, $request->month, $request->year);

                    // Define the target directory and ensure it exists
                    $basePath = '/home3/vrajdahj/vrajphysioapp.vrajdentalclinic.com/reports';
                    if (!file_exists($basePath)) {
                        mkdir($basePath, 0755, true); // Create the directory with appropriate permissions
                    }
                    
                    // Define the file path
                    $fileName = 'daily_collection_report_' . now()->format('Y_m_d_H_i_s') . '.xlsx';
                    $filePath = $basePath . '/' . $fileName;
                    
                    // Store the Excel file
                    Excel::store($export, 'export/' . $fileName, 'public'); // Adjust path relative to 'public' disk
                    
                    // Generate the public file URL
                    $fileUrl = asset('reports/export/' . $fileName);
                    
                    return response()->json([
                        'status' => 'success',
                        'file_url' => $fileUrl]);
                        
                    }
                                return response()->json([
                                    'status' => 'success',
                                    'message' => 'Daily Collection Report',
                                    'daily_collection' => $pList
                                ]);

                    } else 
                    {
                        return response()->json([
                            'status' => 'error',
                            'message' => 'No Data Found!',
                            'daily_collection' => []
                        ]);
                    }



            }else{
                    return response()->json([
                            'status' => 'error',
                            'message' => 'User is not Authorised.',
                    ], 401);
                }



            } catch (ValidationException $e) {
            return response()->json(['errors' => $e->errors()], 422);
        } catch (\Throwable $th) {
            return response()->json(['error' => $th->getMessage()], 500);
        }

    }
        public function total_patient_collection_report(Request $request)
    {
       try
        {
            if(auth()->guard('api')->user())
            {
                 $User = auth()->guard('api')->user();
                 
                    if($request->device_token != $User->device_token)
                    {
                        return response()->json([
                            "ErrorCode" => "1",
                            'Status' => 'Failed',
                            'Message' => 'Device Token Not Match',
                        ], 401);
                    }

                $OrderPayment=OrderPayment::select('orderpayment.*',DB::raw("(SELECT CONCAT(patient_master.patient_first_name, ' ', patient_master.patient_last_name) 
                  FROM patient_master WHERE patient_master.patient_id = patientordermaster.patient_id LIMIT 1) AS patient_name")
                    ,'patientordermaster.patient_id','patientordermaster.DueAmount','patientordermaster.iAmount')
                    ->join('patientorderdetail', 'patientorderdetail.iOrderDetailId', '=', 'orderpayment.orderDetailId')
                    ->join('patientordermaster', 'patientordermaster.iOrderId', '=', 'patientorderdetail.iOrderId')
                    ->when($request->fromdate || $request->todate || $request->month || $request->year, function ($query) use ($request) 
                        {
                            if ($request->fromdate) {
                                $query->where('PaymentDateTime', '>=', date('Y-m-d 00:00:00', strtotime($request->fromdate)));
                            }
                            if ($request->todate) {
                                $query->where('PaymentDateTime', '<=', date('Y-m-d 23:59:59', strtotime($request->todate)));
                            }
                            if ($request->month) {
                                $query->whereMonth('PaymentDateTime', $request->month);
                            }
                            if ($request->year) {
                                $query->whereYear('PaymentDateTime', $request->year);
                            }

                        })
                    ->get();
                    if(sizeof($OrderPayment) != 0)
                    {

                        foreach ($OrderPayment as $key => $val) 
                        {
                             $totalPaid = OrderPayment::where(['iOrderId' => $val->iOrderId])->sum('Amount');
                               
                                $pList[] = array(
                                    "receipt_no" => $val->receipt_no,
                                    "payment_date" => date('d-M-Y',strtotime($val->PaymentDateTime)),
                                    "patient_name" => $val->patient_name,
                                    "payment_mode"=>$val->payment_mode,
                                    "amount"=>$val->Amount
                                );
                        }
                        if($request->status == 1)
                    {
                        
                    
                      $export = new PatientCollection($pList, $request->fromdate, $request->todate, $request->month, $request->year);

                    // Define the target directory and ensure it exists
                    $basePath = '/home3/vrajdahj/vrajphysioapp.vrajdentalclinic.com/reports';
                    if (!file_exists($basePath)) {
                        mkdir($basePath, 0755, true); // Create the directory with appropriate permissions
                    }
                    
                    // Define the file path
                    $fileName = 'Patient_Collection_Report_' . now()->format('Y_m_d_H_i_s') . '.xlsx';
                    $filePath = $basePath . '/' . $fileName;
                    
                    // Store the Excel file
                    Excel::store($export, 'export/' . $fileName, 'public'); // Adjust path relative to 'public' disk
                    
                    // Generate the public file URL
                    $fileUrl = asset('reports/export/' . $fileName);
                    
                    return response()->json([
                        'status' => 'success',
                        'file_url' => $fileUrl
                        ]);
                        
                    }
                                return response()->json([
                                    'status' => 'success',
                                    'message' => 'Total Patient Collection Report',
                                    'total_patient_collection' => $pList
                                ]);

                    } else 
                    {
                        return response()->json([
                            'status' => 'error',
                            'message' => 'No Data Found!',
                            'total_patient_collection' => []
                        ]);
                    }



            }else{
                    return response()->json([
                            'status' => 'error',
                            'message' => 'User is not Authorised.',
                    ], 401);
                }

        } catch (ValidationException $e) {
            return response()->json(['errors' => $e->errors()], 422);
        } catch (\Throwable $th) {
            return response()->json(['error' => $th->getMessage()], 500);
        }
    }
     public function groupsession_report(Request $request)
    {
         try 
        {
            if(auth()->guard('api')->user())
            {
                 $User = auth()->guard('api')->user();
                 
                    if($request->device_token != $User->device_token)
                    {
                        return response()->json([
                            "ErrorCode" => "1",
                            'Status' => 'Failed',
                            'Message' => 'Device Token Not Match',
                        ], 401);
                    }
                    //\DB::enableQueryLog(); // Enable query log

                    $attendedSession =SessionMaster::select(['sessionmaster.created_at','sessionmaster.SessionStartTime','sessionmaster.SessionEndTime','sessionmaster.patient_id','patientin.isGroupSession',DB::raw('(SELECT treatment_name FROM treatment_master WHERE treatment_master.treatment_id = sessionmaster.treatment_id LIMIT 1) AS treatment_name'),
                        DB::raw('(SELECT name FROM users WHERE users.id = sessionmaster.therapist_id LIMIT 1) AS therapist_name'),
                        DB::raw('(SELECT CONCAT(patient_master.patient_first_name, " ", patient_master.patient_last_name) FROM patient_master WHERE patient_master.patient_id = sessionmaster.patient_id LIMIT 1) AS patient_name'),
                        DB::raw('(SELECT clinic_id FROM plan_master WHERE plan_master.treatment_id = sessionmaster.treatment_id LIMIT 1) AS clinic_id')
                    ])
                    // ->where('sessionmaster.session_status', 2)
                    ->when($request->patient_id, fn($query, $patient_id) => $query->where('sessionmaster.patient_id', '=', $patient_id))
                    ->when($request->fromdate, function ($query) use ($request) {
                        return $query->where('sessionmaster.created_at', '>=', date('Y-m-d 00:00:00', strtotime($request->fromdate)));
                    })
                    ->when($request->todate, function ($query) use ($request) {
                        return $query->where('sessionmaster.created_at', '<=', date('Y-m-d 23:59:59', strtotime($request->todate)));
                    })
                    ->when($request->month, function ($query) use ($request) {
                        return $query->whereMonth('sessionmaster.created_at', $request->month);
                    })
                    ->when($request->year, function ($query) use ($request) {
                        return $query->whereYear('sessionmaster.created_at', $request->year);
                    })
                    ->join('patientin', function ($join) {
                        $join->on('patientin.iPatientInId', '=', 'sessionmaster.iPatientInId');
                    }) 
                    ->orderBy('sessionmaster.created_at','asc')
                    ->groupBy('iSessionTakenId')
                    ->get();
///dd(\DB::getQueryLog()); // Show results of log

                         
                        $sessionList=[];
                        $sessionList2=[];
                        $session=0;
                        $amount=0;
                        $total=0;
                        $groupsession=0;
                    foreach ($attendedSession as $key => $val) 
                    {
                            
                            if($val->isGroupSession == 1)
                            {
                                $groupsession="yes";
                            }
                            else{
                                $groupsession="no";
                            }
                            $sessionList[] = array
                            (               
                                    "patient_id" => $val->patient_id,
                                    "patient_name" => $val->patient_name,
                                    "date"=>$val->created_at,
                                    "start_time" => $val->SessionStartTime,
                                    "end_time" => $val->SessionEndTime,
                                    "therapist_name" => $val->therapist_name ?? '-',
                                    "treatment_name" => $val->treatment_name,
                                    "group_session" => $groupsession

                                );
                                $sessionList2[] = array
                                (               
                                    "patient_name" => $val->patient_name,
                                    "date"=>$val->created_at,
                                    "start_time" => $val->SessionStartTime,
                                    "end_time" => $val->SessionEndTime,
                                    "therapist_name" => $val->therapist_name ?? '-',
                                    "treatment_name" => $val->treatment_name,
                                    "group_session" => $groupsession

                                );
                    }
                    if($request->status == 1)
                    {
                        
                    
                      $export = new GroupSessionExport($sessionList2, $request->patient_id, $request->fromdate, $request->todate, $request->month, $request->year);

                    // Define the target directory and ensure it exists
                    $basePath = '/home3/vrajdahj/vrajphysioapp.vrajdentalclinic.com/reports';
                    if (!file_exists($basePath)) {
                        mkdir($basePath, 0755, true); // Create the directory with appropriate permissions
                    }
                    
                    // Define the file path
                    $fileName = 'Group_session_report_' . now()->format('Y_m_d_H_i_s') . '.xlsx';
                    $filePath = $basePath . '/' . $fileName;
                    
                    // Store the Excel file
                    Excel::store($export, 'export/' . $fileName, 'public'); // Adjust path relative to 'public' disk
                    
                    // Generate the public file URL
                    $fileUrl = asset('reports/export/' . $fileName);
                    
                    return response()->json([
                        'status' => 'success',
                        'file_url' => $fileUrl
                        ]);
                        
                    }

                    return response()->json([
                        'status' => 'success',
                        'message' => 'Attended Session List',
                        'Attended Session List' => $sessionList,
                    ]);
            }else{
                    return response()->json([
                            'status' => 'error',
                            'message' => 'User is not Authorised.',
                    ], 401);
                }

        } catch (ValidationException $e) {
            return response()->json(['errors' => $e->errors()], 422);
        } catch (\Throwable $th) {
            return response()->json(['error' => $th->getMessage()], 500);
        }
    }
   public function patient_visit_report(Request $request)
{
    try {
        if (!auth()->guard('api')->user()) {
            return response()->json([
                'status' => 'error',
                'message' => 'User is not Authorised.',
            ], 401);
        }

        $user = auth()->guard('api')->user();

        if ($request->device_token != $user->device_token) {
            return response()->json([
                'ErrorCode' => '1',
                'Status'    => 'Failed',
                'Message'   => 'Device Token Not Match',
            ], 401);
        }

        $clinicId = $request->input('clinic_id');
        $month    = $request->input('month');
        $year     = $request->input('year');
        $fromDate = $request->input('from_date', $request->input('fromdate'));
        $toDate   = $request->input('to_date', $request->input('todate'));

        $hasMonthYearFilter = !empty($month) && !empty($year);
        $hasDateRangeFilter = !empty($fromDate) && !empty($toDate);

        /*
        |--------------------------------------------------------------------------
        | STEP 1: All treatments with default 0
        |--------------------------------------------------------------------------
        */
        $defaultTreatments = DB::table('treatment_master')
            ->where('isDelete', 0)
            ->pluck('treatment_name')
            ->mapWithKeys(function ($name) {
                return [strtoupper(trim($name)) => 0];
            })
            ->toArray();

        /*
        |--------------------------------------------------------------------------
        | STEP 2: Get patient+treatment from sessionmaster for searching
        | Search/filter is based on sessionmaster.created_at
        | Display value is from patient_suggested_treatment.iUsedSession
        |--------------------------------------------------------------------------
        */
        $query = DB::table('sessionmaster as sm')
            ->join('patient_master as pm', 'sm.patient_id', '=', 'pm.patient_id')
            ->join('treatment_master as tm', 'sm.treatment_id', '=', 'tm.treatment_id')
            ->leftJoin('patient_suggested_treatment as pst', function ($join) {
                $join->on('pst.patient_id', '=', 'sm.patient_id')
                     ->on('pst.treatment_id', '=', 'sm.treatment_id');
            })
            ->where('sm.session_status', 2);

        if (!empty($clinicId)) {
            $query->where('pm.clinic_id', $clinicId);
        }

        if ($hasMonthYearFilter) {
            $query->whereYear('sm.created_at', $year)
                  ->whereMonth('sm.created_at', $month);
        }

        if ($hasDateRangeFilter) {
            $query->whereBetween('sm.created_at', [$fromDate, $toDate]);
        }

        $results = $query->select(
                'sm.patient_id',
                'sm.treatment_id',
                DB::raw("CONCAT(COALESCE(pm.patient_first_name, ''), ' ', COALESCE(pm.patient_last_name, '')) as patient_name"),
                DB::raw("UPPER(tm.treatment_name) as treatment_name"),
                DB::raw("COALESCE(MIN(pst.iUsedSession), 0) as session_count")
            )
            ->groupBy(
                'sm.patient_id',
                'sm.treatment_id',
                'pm.patient_first_name',
                'pm.patient_last_name',
                'tm.treatment_name'
            )
            ->orderBy('patient_name')
            ->get();

        /*
        |--------------------------------------------------------------------------
        | STEP 3: Build final array with all treatments defaulting to 0
        |--------------------------------------------------------------------------
        */
        $finalData = [];

        foreach ($results as $row) {
            $patientName   = trim($row->patient_name);
            $treatmentName = strtoupper(trim($row->treatment_name));
            $sessionCount  = (int) $row->session_count;

            if (!isset($finalData[$patientName])) {
                $finalData[$patientName] = [
                    'patient_name' => $patientName,
                    'treatments'   => $defaultTreatments,
                ];
            }

            if (array_key_exists($treatmentName, $finalData[$patientName]['treatments'])) {
                $finalData[$patientName]['treatments'][$treatmentName] = $sessionCount;
            } else {
                $finalData[$patientName]['treatments'][$treatmentName] = $sessionCount;
            }
        }

        /*
        |--------------------------------------------------------------------------
        | STEP 4: Add total
        |--------------------------------------------------------------------------
        */
        foreach ($finalData as $patient => &$data) {
            $data['total'] = array_sum($data['treatments']);

            $data = [
                'patient_name' => $data['patient_name'],
                'total'        => $data['total'],
                'treatments'   => $data['treatments'],
            ];
        }
        unset($data);

        $patientVisitArray = array_values($finalData);

        /*
        |--------------------------------------------------------------------------
        | STEP 5: Excel export
        |--------------------------------------------------------------------------
        */
        if ($request->status == 1) {
            $export = new PatientVisit(
                $patientVisitArray,
                $request->fromdate,
                $request->todate,
                $request->month,
                $request->year
            );

            $basePath = '/home3/vrajdahj/vrajphysioapp.vrajdentalclinic.com/reports';
            if (!file_exists($basePath)) {
                mkdir($basePath, 0755, true);
            }

            $fileName = 'Patient_visit_Report_' . now()->format('Y_m_d_H_i_s') . '.xlsx';

            Excel::store($export, 'export/' . $fileName, 'public');

            $fileUrl = asset('reports/export/' . $fileName);

            return response()->json([
                'status'   => 'success',
                'file_url' => $fileUrl,
            ]);
        }

        return response()->json([
            'status'               => 'success',
            'message'              => 'Patient Visit Count',
            'Patient Visit Count'  => $patientVisitArray,
        ]);

    } catch (ValidationException $e) {
        return response()->json([
            'errors' => $e->errors()
        ], 422);
    } catch (\Throwable $th) {
        return response()->json([
            'error' => $th->getMessage()
        ], 500);
    }
}

    public function upcoming_renewal_report(Request $request)
{
    try {
        if (!auth()->guard('api')->user()) {
            return response()->json([
                'status'  => 'error',
                'message' => 'User is not Authorised.',
            ], 401);
        }

        $User = auth()->guard('api')->user();

        if ($request->device_token != $User->device_token) {
            return response()->json([
                "ErrorCode" => "1",
                'Status'    => 'Failed',
                'Message'   => 'Device Token Not Match',
            ], 401);
        }

        $latestSchedule = PatientSchedule::query()
            ->join('patient_master', 'patient_master.patient_id', '=', 'patient_schedule.patient_id')
            ->join('patientordermaster', 'patientordermaster.iOrderId', '=', 'patient_schedule.orderId')
            ->join('patientorderdetail', function ($join) {
                $join->on('patientorderdetail.iOrderId', '=', 'patientordermaster.iOrderId')
                     ->on('patientorderdetail.iTreatmentId', '=', 'patient_schedule.treatment_id');
            })
            ->where('patient_master.clinic_id', $request->clinic_id)
            ->where('patientorderdetail.cancel_package', 0)  // ✅ moved here
            ->selectRaw('MAX(patient_schedule.patient_schedule_id) as last_id')
            ->groupBy(
                'patient_schedule.patient_id',
                'patient_schedule.orderId',
                'patient_schedule.treatment_id',
                'patientorderdetail.iOrderDetailId'
            );
        
        $schedule = PatientSchedule::query()
            ->joinSub($latestSchedule, 'ls', function ($join) {
                $join->on('patient_schedule.patient_schedule_id', '=', 'ls.last_id');
            })
            ->join('patient_master', 'patient_master.patient_id', '=', 'patient_schedule.patient_id')
            ->join('patientordermaster', 'patientordermaster.iOrderId', '=', 'patient_schedule.orderId')
            ->join('patientorderdetail', function ($join) {
                $join->on('patientorderdetail.iOrderId', '=', 'patientordermaster.iOrderId')
                     ->on('patientorderdetail.iTreatmentId', '=', 'patient_schedule.treatment_id');
            })
            ->where('patient_master.clinic_id', $request->clinic_id)
            ->where('patientorderdetail.cancel_package', 0) // ✅ and here too
            ->select(
                'patient_schedule.patient_id',
                'patient_schedule.treatment_id',
                'patient_schedule.orderId',
                'patient_master.clinic_id',
                'patient_master.phone',
                'patientorderdetail.iAmount as total_amount',
                'patientorderdetail.iDueAmount as due_amount',
                'patientorderdetail.iPlanId',
                'patientorderdetail.iOrderDetailId',
                'patientorderdetail.iOrderId',
                'patientorderdetail.iSession as total_session_buy',
                'patientordermaster.created_at',
                DB::raw("CONCAT(patient_master.patient_first_name,' ',patient_master.patient_last_name) as patient_name")
            )
            ->orderByDesc('patient_schedule.patient_schedule_id')
            ->get();


        if ($schedule->isEmpty()) {
            return response()->json([
                'status' => 'error',
                'message' => 'No Data Found',
                'upcoming_renewal' => []
            ]);
        }

        $renewalList = [];
        $seen = []; // ✅ extra protection from duplicates

        foreach ($schedule as $row) {

            // ✅ unique key per package/treatment
            $uniqKey = $row->patient_id . '|' . $row->iOrderId . '|' . $row->iOrderDetailId . '|' . $row->treatment_id;
            if (isset($seen[$uniqKey])) continue;

            $session = PatientSuggestedTreatment::where([
                'patient_id'     => $row->patient_id,
                'iOrderId'       => $row->iOrderId,
                'iOrderDetailId' => $row->iOrderDetailId,
                'treatment_id'   => $row->treatment_id,
            ])->first();

            if (!$session) continue;

            $plan = Plan::select('plan_master.per_session_amount', 'plan_name')
                ->where('plan_id', $row->iPlanId)
                ->first();

            if (!$plan) continue;

            $perSession = (float)($plan->per_session_amount ?? 0);

            $totalAmount = (float)($row->total_amount ?? 0);
            $dueAmount   = (float)($row->due_amount ?? 0);
            $totalPaid   = $totalAmount - $dueAmount;

            $paidSession = ($perSession > 0) ? ($totalPaid / $perSession) : 0;

            $usedSession = (float)($session->iUsedSession ?? 0);
            $availableSession = $paidSession - $usedSession;

            $totalBuy = (float)($row->total_session_buy ?? 0);
            $dueSession = $totalBuy - $paidSession;

            // ✅ only if available sessions <= 2
            $perSession = (float)($plan->per_session_amount ?? 0);

            $totalAmount = (float)($row->total_amount ?? 0);
            $dueAmount   = (float)($row->due_amount ?? 0);
            $totalPaid   = $totalAmount - $dueAmount;
            
            /*// ✅ paid sessions (integer)
            $paidSession = ($perSession > 0) ? ($totalPaid / $perSession) : 0;
            $paidSessionInt = (int) round($paidSession, 0);
            
            $usedSession = (int) ($session->iUsedSession ?? 0);
            
            // ✅ available sessions (integer, can be negative)
            $availableInt = (int) round($paidSession - $usedSession, 0);
            
            // ✅ EXCLUDE completed (0)
            if ($availableInt === 0) {
                continue;
            }
            
            // ✅ only show <= 2 (includes negative values)
            if ($availableInt > 2) {
                continue;
            }*/
            
            $paidSession = ($perSession > 0) ? ($totalPaid / $perSession) : 0;
            $paidSessionInt = (int) round($paidSession, 0);
            
            $usedSession = (int) ($session->iUsedSession ?? 0);
            
            // ✅ available sessions (integer, can be negative)
            $availableInt = (int) round($paidSession - $usedSession, 0);
            
            // $totalBuy = (int)($row->total_session_buy ?? 0);
            
            $totalBuy = (int)($row->total_session_buy ?? 0);
            $usedSession = (int) ($session->iUsedSession ?? 0);
            
            // ✅ remaining sessions based on TOTAL bought sessions (not paid)
            $availableInt = $totalBuy - $usedSession;
            
            // ✅ don't allow minus or 0 (completed/invalid)
            if ($availableInt <= 0) {
                continue;
            }
            
            // ✅ only show remaining <= 2
            if ($availableInt > 2) {
                continue;
            }
            // ✅ due sessions (integer)
            $dueSessionInt = (int) round($totalBuy - $paidSession, 0);
            
            $seen[$uniqKey] = true;
            
            $renewalList[] = [
                "patient_id"        => $row->patient_id,
                "patient_name"      => $row->patient_name,
                "clinic_id"         => $row->clinic_id,
                "package_name"      => $plan->plan_name,
                "mobile"            => $row->phone,
                "package_buy_date"       => date('d-m-Y',strtotime($row->created_at)),
                "total_session"     => $totalBuy,
                "paid_session"      => $paidSessionInt,
                "due_session"       => $dueSessionInt,
                "consumed_session"  => $usedSession,
                "available_session" => $availableInt, // ✅ no decimals, never 0
            ];

        }

        return response()->json([
            'status' => 'success',
            'message' => 'Upcoming Renewal List',
            'upcoming_renewal' => $renewalList
        ]);

    } catch (ValidationException $e) {
        return response()->json(['errors' => $e->errors()], 422);
    } catch (\Throwable $th) {
        return response()->json(['error' => $th->getMessage()], 500);
    }
}

public function overdue_payment_report(Request $request)
{
    try {
        if (!auth()->guard('api')->user()) {
            return response()->json([
                'status' => 'error',
                'message' => 'User is not Authorised.',
            ], 401);
        }

        $User = auth()->guard('api')->user();

        if ($request->device_token != $User->device_token) {
            return response()->json([
                "ErrorCode" => "1",
                'Status' => 'Failed',
                'Message' => 'Device Token Not Match',
            ], 401);
        }

        $schedule = PatientSchedule::select(
                'patient_schedule.*',
                'patient_master.clinic_id',
                'patient_master.phone',
                'patientorderdetail.iAmount as total_amount',
                'patientorderdetail.iDueAmount as due_amount',
                'patientorderdetail.iPlanId',
                'patientorderdetail.iOrderDetailId',
                'patientorderdetail.iOrderId',
                'patientorderdetail.iSession as total_session_buy',
                'patientordermaster.created_at',
                DB::raw("CONCAT(patient_master.patient_first_name,' ',patient_master.patient_last_name) as patient_name")
            )
            ->join('patient_master', 'patient_master.patient_id', '=', 'patient_schedule.patient_id')
            ->join('patientordermaster', 'patientordermaster.iOrderId', '=', 'patient_schedule.orderId')
            ->join('patientorderdetail', function ($join) {
                $join->on('patientorderdetail.iOrderId', '=', 'patientordermaster.iOrderId')
                     ->on('patientorderdetail.iTreatmentId', '=', 'patient_schedule.treatment_id');
            })
            ->where('patient_master.clinic_id', $request->clinic_id)
            ->where('patientorderdetail.cancel_package', 0)
            ->groupBy('patientorderdetail.iOrderDetailId')
            ->orderByDesc('patient_schedule.patient_schedule_id')
            ->get();

        if ($schedule->isEmpty()) {
            return response()->json([
                'status' => 'error',
                'message' => 'No Data Found',
                'upcoming_renewal' => []
            ]);
        }

        $renewalList = [];
        $seen = [];

        foreach ($schedule as $row) {

            $uniqKey = $row->patient_id . '|' . $row->iOrderId . '|' . $row->iOrderDetailId . '|' . $row->treatment_id;
            if (isset($seen[$uniqKey])) {
                continue;
            }

            $session = PatientSuggestedTreatment::where([
                'patient_id'     => $row->patient_id,
                'iOrderId'       => $row->iOrderId,
                'iOrderDetailId' => $row->iOrderDetailId,
                'treatment_id'   => $row->treatment_id,
            ])->first();

            if (!$session) {
                continue;
            }

            $plan = Plan::select('plan_master.per_session_amount', 'plan_name')
                ->where('plan_id', $row->iPlanId)
                ->first();

            if (!$plan) {
                continue;
            }

            $perSession  = (float) ($plan->per_session_amount ?? 0);
            $totalAmount = (float) ($row->total_amount ?? 0);
            $dueAmount   = (float) ($row->due_amount ?? 0);
            $totalPaid   = $totalAmount - $dueAmount;

            $paidSession = ($perSession > 0) ? ($totalPaid / $perSession) : 0;
            $consumedSession = (float) ($session->iUsedSession ?? 0);

            $availableSession = $paidSession - $consumedSession;

            // round to avoid tiny float negative values like -0.008565...
            $availableSessionRounded = round($availableSession, 0);

            // only actual minus records
            if ($availableSessionRounded >= 0) {
                continue;
            }

            $consumedAmount = $consumedSession * $perSession;
            $availableAmount = $totalPaid - $consumedAmount;
            $dueSession = (float) ($row->total_session_buy ?? 0) - $paidSession;

            $seen[$uniqKey] = true;

            $renewalList[] = [
                "patient_id"         => $row->patient_id,
                "patient_name"       => $row->patient_name,
                "clinic_id"          => $row->clinic_id,
                // "mobile"             => $row->phone,
                "package_name"       => $plan->plan_name,
                "package_buy_date"       => date('d-m-Y',strtotime($row->created_at)),
                "total_session"      => (int) ($row->total_session_buy ?? 0),
                "paid_session"       => (int) round($paidSession, 0),
                "due_session"        => (int) round($dueSession, 0),
                "consumed_session"   => (int) $consumedSession,
                "available_session"  => (int) $availableSessionRounded,
                // "available_amount"   => number_format($availableAmount, 2, '.', ''),
            ];
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Upcoming Renewal List',
            'overdue_payment_report' => array_values($renewalList)
        ]);

    } catch (ValidationException $e) {
        return response()->json([
            'errors' => $e->errors()
        ], 422);
    } catch (\Throwable $th) {
        return response()->json([
            'error' => $th->getMessage()
        ], 500);
    }
}
   public function overdue_payment_report_old(Request $request)
    {
        try {
            if (!auth()->guard('api')->user()) {
                return response()->json([
                    'status'  => 'error',
                    'message' => 'User is not Authorised.',
                ], 401);
            }
    
            $User = auth()->guard('api')->user();
    
            if ($request->device_token != $User->device_token) {
                return response()->json([
                    "ErrorCode" => "1",
                    'Status'    => 'Failed',
                    'Message'   => 'Device Token Not Match',
                ], 401);
            }
    
            $latestSchedule = PatientSchedule::query()
                ->join('patient_master', 'patient_master.patient_id', '=', 'patient_schedule.patient_id')
                ->join('patientordermaster', 'patientordermaster.iOrderId', '=', 'patient_schedule.orderId')
                ->join('patientorderdetail', function ($join) {
                    $join->on('patientorderdetail.iOrderId', '=', 'patientordermaster.iOrderId')
                        ->on('patientorderdetail.iTreatmentId', '=', 'patient_schedule.treatment_id');
                })
                ->where('patient_master.clinic_id', $request->clinic_id)
                ->where('patientorderdetail.cancel_package', 0)
                ->selectRaw('MAX(patient_schedule.patient_schedule_id) as last_id')
                ->groupBy(
                    'patient_schedule.patient_id',
                    'patient_schedule.orderId',
                    'patient_schedule.treatment_id',
                    'patientorderdetail.iOrderDetailId'
                );
    
            $schedule = PatientSchedule::query()
                ->joinSub($latestSchedule, 'ls', function ($join) {
                    $join->on('patient_schedule.patient_schedule_id', '=', 'ls.last_id');
                })
                ->join('patient_master', 'patient_master.patient_id', '=', 'patient_schedule.patient_id')
                ->join('patientordermaster', 'patientordermaster.iOrderId', '=', 'patient_schedule.orderId')
                ->join('patientorderdetail', function ($join) {
                    $join->on('patientorderdetail.iOrderId', '=', 'patientordermaster.iOrderId')
                        ->on('patientorderdetail.iTreatmentId', '=', 'patient_schedule.treatment_id');
                })
                ->where('patient_master.clinic_id', $request->clinic_id)
                ->where('patientorderdetail.cancel_package', 0)
                ->select(
                    'patient_schedule.patient_id',
                    'patient_schedule.treatment_id',
                    'patient_schedule.orderId',
                    'patient_master.clinic_id',
                    'patient_master.phone',
                    'patientorderdetail.iAmount as total_amount',
                    'patientorderdetail.iDueAmount as due_amount',
                    'patientorderdetail.iPlanId',
                    'patientorderdetail.iOrderDetailId',
                    'patientorderdetail.iOrderId',
                    'patientorderdetail.iSession as total_session_buy',
                    DB::raw("CONCAT(patient_master.patient_first_name,' ',patient_master.patient_last_name) as patient_name")
                )
                ->orderByDesc('patient_schedule.patient_schedule_id')
                ->get();
    
            if ($schedule->isEmpty()) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'No Data Found',
                    'overdue_payment_report' => []
                ]);
            }
    
            $renewalList = [];
            $seen = [];
    
            foreach ($schedule as $row) {
                $uniqKey = $row->patient_id . '|' . $row->iOrderId . '|' . $row->iOrderDetailId . '|' . $row->treatment_id;
    
                if (isset($seen[$uniqKey])) {
                    continue;
                }
    
                $session = PatientSuggestedTreatment::where([
                    'patient_id'     => $row->patient_id,
                    'iOrderId'       => $row->iOrderId,
                    'iOrderDetailId' => $row->iOrderDetailId,
                    'treatment_id'   => $row->treatment_id,
                ])->first();
    
                if (!$session) {
                    continue;
                }
    
                $plan = Plan::select('plan_master.per_session_amount', 'plan_name')
                    ->where('plan_id', $row->iPlanId)
                    ->first();
    
                if (!$plan) {
                    continue;
                }
    
                $perSession  = (float) ($plan->per_session_amount ?? 0);
                $totalAmount = (float) ($row->total_amount ?? 0);
                $dueAmount   = (float) ($row->due_amount ?? 0);
                $totalPaid   = $totalAmount - $dueAmount;
    
                $paidSession    = ($perSession > 0) ? ($totalPaid / $perSession) : 0;
                $paidSessionInt = (int) round($paidSession, 0);
    
                $totalBuy    = (int) ($row->total_session_buy ?? 0);
                $usedSession = (int) ($session->iUsedSession ?? 0);
    
                // remaining session from total bought
                $availableInt = $totalBuy - $usedSession;
    
                // only negative records
                if ($availableInt >= 0) {
                    continue;
                }
    
                $dueSessionInt = (int) round($totalBuy - $paidSession, 0);
    
                $seen[$uniqKey] = true;
    
                $renewalList[] = [
                    "patient_id"        => $row->patient_id,
                    "patient_name"      => $row->patient_name,
                    "clinic_id"         => $row->clinic_id,
                    "package_name"      => $plan->plan_name,
                    "mobile"            => $row->phone,
                    "total_session"     => $totalBuy,
                    "paid_session"      => $paidSessionInt,
                    "due_session"       => $dueSessionInt,
                    "consumed_session"  => $usedSession,
                    "available_session" => $availableInt, // only minus values
                ];
            }
    
            return response()->json([
                'status' => 'success',
                'message' => 'overduew payment List',
                'overdue_payment_report' => $renewalList
            ]);
    
        } catch (ValidationException $e) {
            return response()->json([
                'errors' => $e->errors()
            ], 422);
        } catch (\Throwable $th) {
            return response()->json([
                'error' => $th->getMessage()
            ], 500);
        }
    }
}